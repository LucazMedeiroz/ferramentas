#urls



from django.urls import path, include
from . import views


urlpatterns = [
    path('', views.encomendasAbertas, name='encomendas'),
    path('get_marcas', views.get_marcas, name='get_marcas'),
    path('get_modelos', views.get_modelos, name='get_modelos'),
    path('excel', views.encomendasAbertas, name='encomendas_abertas_excel')

    
]

