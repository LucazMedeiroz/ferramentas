import pyodbc
import datetime

def encoemndasAbertas(data_inicio, data_fim):
    query1 = """
        SELECT obrano, design, usr1 AS MARCA, usr2 AS MODELO, qtt, qtt2 AS entregue,
               (qtt - qtt2) AS em_aberto, CONVERT(date, rdata) AS data_para_entrega
        FROM bi
        WHERE ndos = 1 AND fechada = 0 AND qtt2 < qtt
          AND rdata >= ? AND rdata <= ?
        ORDER BY obrano ASC, ref, data_para_entrega
    """

    query2 = """
        SELECT nave, st.u_cor, SUM(u_stock_diario.stock) as STOCK
        FROM u_stock_diario
        INNER JOIN st ON u_stock_diario.REF = st.ref
        WHERE COMPONENTE = 'QUADRO' AND ANO = 2024 AND MES = 06 AND DIA = 27 AND MARCA = ? AND MODELO = ?
        GROUP BY nave, st.u_cor
    """

    # Substitua por sua string de conexão real
    conn_str = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER=192.168.120.9;DATABASE=PHCTRI;UID=estagio;PWD=3stAg10..'
    conn = pyodbc.connect(conn_str)
    cursor = conn.cursor()
    
    # Execute a consulta inicial com parâmetros
    cursor.execute(query1, data_inicio, data_fim)
    results = cursor.fetchall()
    
    # Transforme os resultados em um formato utilizável
    columns = [column[0] for column in cursor.description]
    data = [dict(zip(columns, row)) for row in results]
    
    
    # Obtenha a data atual
    #hoje = datetime.datetime.today()
    #ano_atual = hoje.year
    #mes_atual = hoje.month
    #dia_atual = hoje.day
    
    # Para cada linha dos dados, execute a segunda consulta para buscar o estoque
    for row in data:
        cursor.execute(query2, row['MARCA'], row['MODELO'])
        estoque = cursor.fetchone()
        if estoque:
            row['nave'] = estoque.nave
            row['u_cor'] = estoque.u_cor
            row['STOCK'] = estoque.STOCK
        else:
            row['nave'] = None
            row['u_cor'] = None
            row['STOCK'] = None
    
    conn.close()
    return data
