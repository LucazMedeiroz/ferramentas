from turtle import pd
import pyodbc
from collections import defaultdict
from datetime import datetime

def encomendasAbertasUtils(data_inicio=None, data_fim=None, cliente=None, marca=None, modelo=None):
    # Logs iniciais
    print('data_inicio:', data_inicio)
    print('data_fim:', data_fim)
    print('cliente:', cliente)
    print('marca:', marca)
    print('modelo:', modelo)
    
    # Definição da query base
    query_base = """
-- Subquery para obter a última data de atualização do inventário
WITH last_stock_date AS (
    SELECT MAX(CONVERT(date, CONCAT(ANO, '-', MES, '-', DIA))) AS last_date
    FROM u_stock_diario
)

-- Query principal
SELECT 
    bi.obrano, 
    bi.ref, 
    bi.design, 
    bi.usr1 AS MARCA, 
    bi.usr2 AS MODELO, 
    bi.qtt, 
    bi.qtt2 AS entregue,
    (bi.qtt - bi.qtt2) AS em_aberto, 
    CONVERT(date, bi.rdata) AS data_para_entrega, 
    st.u_tamanho AS tamanho, 
    (bi.rdata - 1) as data_para_entrega_menos_um, 
    COALESCE(stock_info.STOCK, 0) AS quadro_stock, 
    stock_info.u_cor AS cor
FROM 
    bi WITH (NOLOCK)
INNER JOIN 
    st ON bi.ref = st.ref
LEFT JOIN (
    SELECT 
        u_stock_diario.ref, 
        st.u_cor, 
        SUM(u_stock_diario.stock) AS STOCK
    FROM 
        u_stock_diario WITH (NOLOCK)
    INNER JOIN 
        st ON u_stock_diario.ref = st.ref
    WHERE 
        COMPONENTE = 'QUADRO' 
        AND u_stock_diario.nave = 4
        AND CONVERT(date, CONCAT(ANO, '-', MES, '-', DIA)) = (SELECT last_date FROM last_stock_date)
    GROUP BY 
        u_stock_diario.ref, 
        st.u_cor
) AS stock_info 
    ON bi.ref = stock_info.ref
WHERE 
    bi.ndos = 1 
    AND bi.fechada = 0 
    AND bi.qtt2 < bi.qtt


    """

    # Condições de filtro
    conditions = []
    parameters = []

    if data_inicio:
        conditions.append("bi.rdata >= ?")
        parameters.append(data_inicio)

    if data_fim:
        conditions.append("bi.rdata <= ?")
        parameters.append(data_fim)

    if cliente:
        conditions.append("bi.nome = ?")
        parameters.append(cliente)

    if marca:
        conditions.append("bi.usr1 = ?")
        parameters.append(marca)

    if modelo:
        conditions.append("bi.usr2 = ?")
        parameters.append(modelo)

    # Compondo a query final
    if conditions:
        query1 = query_base + " AND " + " AND ".join(conditions)
    else:
        query1 = query_base

    query1 += " ORDER BY bi.obrano ASC, bi.ref, data_para_entrega"

    # Log da query final
    print('query1:', query1)

    # Query para obter a última data de atualização do inventário
    query_get_last_date = """
        SELECT MAX(CONVERT(date, CONCAT(ANO, '-', MES, '-', DIA))) AS last_date
        FROM u_stock_diario
    """

    query2 = """
        SELECT nave, st.u_cor, SUM(u_stock_diario.stock) as STOCK
        FROM u_stock_diario  WITH (NOLOCK)
        INNER JOIN st ON u_stock_diario.REF = st.ref
        WHERE COMPONENTE = 'QUADRO' AND CONVERT(date, CONCAT(ANO, '-', MES, '-', DIA)) = ? AND MARCA = ? AND MODELO = ? AND st.u_tamanho = ?
        GROUP BY nave, st.u_cor
    """

    query_armazem = """
        SELECT ref, SUM(stock) as STOCK
        FROM sa  WITH (NOLOCK)
        WHERE armazem = 35 AND ref = ?
        GROUP BY ref
    """
    query_embalamento = """
        SELECT ref, SUM(stock) as STOCK
        FROM sa  WITH (NOLOCK)
        WHERE armazem = 8 AND ref = ?
        GROUP BY ref
    """

    query_embalamento2 = """
	   SELECT SUM(s.stock) as STOCK,  b.usr1, b.usr2, st.u_tamanho
        FROM sa s
		inner join bi b
		on b.ref = s.ref
        inner join st
        on st.ref = s.ref
        WHERE s.armazem = 8 and b.usr1 = ? and b.usr2 = ? and st.u_tamanho = ?
        GROUP BY  b.usr1, b.usr2, st.u_tamanho
        """

    query_estoque_detalhado = """
        SELECT lang5, SUM(sa.stock) AS stock
        FROM st  WITH (NOLOCK)

        inner join sa on st.ref=sa.ref

        WHERE usr1 = ? AND usr2 = ? AND u_tamanho = ? AND u_nave = ? AND lang4 = 'QUADRO' and sa.armazem=8
        GROUP BY lang5
    """



    # Log das demais queries
    print('query_get_last_date:', query_get_last_date)
    print('query2:', query2)
    print('query_armazem:', query_armazem)
    print('query_estoque_detalhado:', query_estoque_detalhado)

    conn_str = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER=192.168.120.9;DATABASE=PHCTRI;UID=estagio;PWD=3stAg10..'
    conn = pyodbc.connect(conn_str)
    cursor = conn.cursor()

    # Obter a última data de atualização do inventário
    cursor.execute(query_get_last_date)
    last_date_result = cursor.fetchone()
    last_date = last_date_result[0]

    print('--------------------------------LAST DATE----------------------------------------------')

    print(last_date)

    # Executar a consulta principal
    cursor.execute(query1, tuple(parameters))

    results = cursor.fetchall()

    columns = [column[0] for column in cursor.description]
    data = [dict(zip(columns, row)) for row in results]

    for row in data:
        cursor.execute(query2, last_date, row['MARCA'].strip(), row['MODELO'].strip(), row['tamanho'])
        estoques = cursor.fetchall()

        row['nave2'] = 0
        row['nave3'] = 0
        row['nave4'] = 0
        row['u_cor'] = []
        row['cores'] = []

        estoque_nave4 = 0

        for estoque in estoques:
            if estoque.nave == 2:
                row['nave2'] = estoque.STOCK
            elif estoque.nave == 3:
                row['nave3'] = estoque.STOCK
            elif estoque.nave == 4:
                estoque_nave4 += estoque.STOCK
                row['cores'].append({'cor': estoque.u_cor, 'stock': estoque.STOCK})

        row['nave4'] = estoque_nave4
        row['sem_cores'] = 0


        #número de stock onde cor is null
        for c in row['cores']:
            if c['cor'] == None:
                row['sem_cores'] += c['stock']

        #número de stock onde cor is null
        print('--------------------------------------')
        print(row['sem_cores'])


        
            



                             

   

 





        row['nave4_null'] = sum([c['stock'] for c in row['cores'] if c['cor'] == None])

        

        # Obter o estoque no armazém 35 para cada ref
        cursor.execute(query_armazem, row['ref'])
        armazem_result = cursor.fetchone()
        row['estoque_armazem'] = armazem_result.STOCK if armazem_result else 0

        row['total_entregue'] = sum([r['entregue'] for r in data])

        # Calcular o número da semana
        row['semana'] = row['data_para_entrega'].isocalendar()[1]

        cursor.execute(query_embalamento2, row['MARCA'].strip(), row['MODELO'].strip(), row['tamanho'].strip())
        embalamento = cursor.fetchall()
        row['embalamento'] = embalamento[0].STOCK if embalamento else 0

        cursor.execute(query_embalamento, row['ref'])
        embalamentoRef = cursor.fetchone()
        row['embalamentoRef'] = embalamentoRef.STOCK if embalamentoRef else 0




  
        





        estoques_detalhados = {2: {}, 3: {}, 4: {}}
        for nave in estoques_detalhados.keys():
            cursor.execute(query_estoque_detalhado, row['MARCA'].strip(), row['MODELO'].strip(), row['tamanho'].strip(), nave)
            detalhes_estoque = cursor.fetchall()
            for detalhe in detalhes_estoque:
                estoques_detalhados[nave][detalhe.lang5.strip()] = detalhe.stock

        row['estoque_detalhado'] = estoques_detalhados

        # Log do estoque detalhado
        print('Estoque detalhado para', row['MARCA'], row['MODELO'], row['tamanho'])
        print(row['estoque_detalhado'])

    conn.close()

    grouped_data = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(list))))

    for row in data:
        marca = row['MARCA'].strip()
        modelo = row['MODELO'].strip()
        tamanho = row['tamanho'].strip()
        semana = row['semana']
        mes = row['data_para_entrega'].month
        ano = row['data_para_entrega'].year

        grouped_data[(semana, mes, ano)][marca][modelo][tamanho].append(row)

    final_data = []
    for (semana, mes, ano), marcas in grouped_data.items():
        for marca, modelos in marcas.items():
            for modelo, tamanhos in modelos.items():
                for tamanho, rows in tamanhos.items():
                    total_qtt = sum(row['qtt'] for row in rows)
                    total_em_aberto = sum(row['em_aberto'] for row in rows)
                    total_entregue = sum(row['entregue'] for row in rows)

                    # Calcular o estoque_armazem somando apenas uma vez por combinação única de ref e design
                    refs_designs_unicos = []
                    total_estoque_armazem = 0
                    total_emabalamento = 0
                    for row in rows:
                        ref_design = f"{row['ref']}_{row['design']}"
                        if ref_design not in refs_designs_unicos:
                            total_estoque_armazem += row['estoque_armazem']
                            total_emabalamento += row['embalamentoRef']
                            refs_designs_unicos.append(ref_design)


                    
                    

                    final_data.append({
                        'semana': semana,
                        'mes': mes,
                        'ano': ano,
                        'MARCA': marca,
                        'MODELO': modelo,
                        'tamanho': tamanho,
                        'total_qtt': total_qtt,
                        'total_em_aberto': total_em_aberto,
                        'total_entregue': total_entregue,
                        'nave2': rows[0]['nave2'],
                        'nave3': rows[0]['nave3'],
                        'nave4': rows[0]['nave4'],
                        'nave4_null': rows[0]['nave4_null'],
                        #total do embalamento
                        'embalamento': rows[0]['embalamento'],

                        'sem_cores': rows[0]['sem_cores'],

                        
                        'estoque_armazem': total_estoque_armazem,
                        'embalamentoRef': total_emabalamento,

                        'estoque_detalhado': rows[0]['estoque_detalhado'], 
                        'detalhes': rows,
                        #nave 2 
                        #'estoque_nave2': rows[0]['estoque_detalhado'][2],
                        #


                        'estoque_nave2': sum(rows[0]['estoque_detalhado'][2].values()),

                        # coluna para a cor que é null
                        'cor': None




                    })

    return final_data







def get_clientes_marcas_modelos():
    query = """
                SELECT 
                    UPPER(TRIM(nome)) as cliente,
                    UPPER(TRIM(usr1)) as marca,
                    UPPER(TRIM(usr2)) as modelo
                FROM 
                    bi  WITH (NOLOCK)
                WHERE 
                    ndos = 1
                GROUP BY 
                    UPPER(TRIM(nome)), 
                    UPPER(TRIM(usr1)), 
                    UPPER(TRIM(usr2))
                ORDER BY 
                    cliente ASC;


        
    """


    conn_str = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER=192.168.120.9;DATABASE=PHCTRI;UID=estagio;PWD=3stAg10..'
    conn = pyodbc.connect(conn_str)
    cursor = conn.cursor()
    cursor.execute(query)
    rows = cursor.fetchall()


    
    # Process the rows into a more usable structure
    results = []
    for row in rows:
        results.append({
            'cliente': row[0],
            'marca': row[1],
            'modelo': row[2],
        })
    return results

def salvar_detalhes_excel(data):
    writer = pd.ExcelWriter('detalhes.xlsx', engine='openpyxl')
    
    for idx, row in enumerate(data):
        detalhes_df = pd.DataFrame(row['detalhes'])
        detalhes_df.to_excel(writer, sheet_name=f'Detalhes {idx + 1}', index=False)
    
    writer.save()

    